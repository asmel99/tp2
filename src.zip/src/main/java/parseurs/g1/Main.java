package parseurs.g1;

public class Main {
	  public static void main(String[] args) {
	        String ch = "bbbcde";

	        TokenManager tm = new TokenManager(ch);
	        ParseurG1 parser = new ParseurG1(tm);

	        try {
	            parser.parse();
	            System.out.println(ch + " est valide");
	        } catch (RuntimeException e) {
	            System.out.println(ch + " n'est pas valide");
	            System.out.println(e.getMessage());
	        }
	    }
}
